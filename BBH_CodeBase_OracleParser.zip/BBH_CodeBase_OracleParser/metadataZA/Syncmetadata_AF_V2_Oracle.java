package com.erwin.cfx.connectors.metadataZA;

import java.io.FileWriter;
import com.ads.api.beans.common.Document;
import com.ads.api.beans.common.Node;
import com.ads.api.beans.mm.Mapping;
import com.ads.api.beans.mm.MappingSpecificationRow;
import com.ads.api.beans.sm.SMColumn;
import com.ads.api.util.KeyValueUtil;
import com.ads.api.util.MappingManagerUtil;
import com.ads.api.util.SystemManagerUtil;
import com.icc.util.ApplicationConstants;
import com.icc.util.RequestStatus;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import org.apache.catalina.util.ServerInfo;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Syncmetadata_AF_V2_Oracle {

    private static final Logger LOGGER = Logger.getLogger(Syncmetadata_AF_V2_Oracle.class);
    static String extreamTargetTableName = "";
    public static HashMap<String, String> colDataType = new HashMap();
    public static String metadatajsonPath = "";
    public static String folderPath = "";
    static String warningMessage = "]::Warning::Error";
    static String log = "";
    public static int totalMappingCount = 0;
    public static int totalProjectCount = 0;
    public static int totalNumberOfSub = 0;
    public static int faliedMappingCOunt = 0;
    public static StringBuilder creatingLogDetailsForCat = new StringBuilder();
    public static StringBuilder logDetails = new StringBuilder();
    public static String over = "Complect";

    //public static StringBuilder forMetadataSynp=new StringBuilder();
    public static List<Mapping> metadataSync(List<String> envMap, SystemManagerUtil smutill, String json, String subjectName, String sqlfilepath, String jsonMetadatapath, String folder) {
        String jsonvalue = "";

        try {
            metadatajsonPath = jsonMetadatapath;
            folderPath = sqlfilepath;
            Map<String, String> sysEnvTableDetails = new HashMap<String, String>();
            Map<String, Map<String, Integer>> tableColDetails = new HashMap<String, Map<String, Integer>>();
            Map<String, Map<Integer, SMColumn>> ColsDetails = new HashMap<String, Map<Integer, SMColumn>>();
            ObjectMapper mapper = new ObjectMapper();
            json = json.replace(",\"childNodes\":[]", "");
            String fromfileschemaName = "";
            String fromfiledatabaseName = "";
            if (sqlfilepath.contains("\\")) {
                fromfileschemaName = sqlfilepath.split("\\\\")[sqlfilepath.split("\\\\").length - 2];
                fromfiledatabaseName = sqlfilepath.split("\\\\")[sqlfilepath.split("\\\\").length - 3];
            } else if (sqlfilepath.contains("/")) {
                fromfileschemaName = sqlfilepath.split("/")[sqlfilepath.split("/").length - 2];
                fromfiledatabaseName = sqlfilepath.split("/")[sqlfilepath.split("/").length - 3];
            } else if (sqlfilepath.contains("//")) {
                fromfileschemaName = sqlfilepath.split("//")[sqlfilepath.split("//").length - 2];
                fromfiledatabaseName = sqlfilepath.split("//")[sqlfilepath.split("//").length - 3];
            }

            List<Mapping> mapObj = (List) mapper.readValue(json, new TypeReference<List<Mapping>>() {
            }
            );
            ArrayList<MappingSpecificationRow> mapSPecsLists = ((Mapping) mapObj.get(0)).getMappingSpecifications();
            envMap.toString();

            String mapName = ((Mapping) mapObj.get(0)).getMappingName();

            mapName = mapName.replaceAll("[^\\w\\s]+", "");

            String storproc = mapName;
            String storprocName = storproc.replaceAll("[0-9]", "");
            if (mapName.contains(".")) {
                storproc = mapName.substring(0, mapName.lastIndexOf("."));
                storprocName = storproc.replaceAll("[0-9]", "");
            }
            subjectName = subjectName.toUpperCase();

            changeresultofTarget(mapSPecsLists, subjectName.toUpperCase(), fromfileschemaName, mapName);
            removebraces(mapSPecsLists);
            List<MappingSpecificationRow> colstars = updatespecrowforstar(mapSPecsLists, envMap, sysEnvTableDetails, tableColDetails, smutill);
            mapSPecsLists.addAll(colstars);
            List<MappingSpecificationRow> insertcols = settingstarColsofInsert(mapSPecsLists);
            mapSPecsLists.addAll(insertcols);
            removestarcolumspec(mapSPecsLists);
            for (MappingSpecificationRow mapSPecs : mapSPecsLists) {
                boolean sourcenamesset = true;
                boolean targetnamesset = true;
                String Sourcetablename = mapSPecs.getSourceTableName();
                if (Sourcetablename.split("\n").length == 1) {
                    if (Sourcetablename.contains(".") && !Sourcetablename.contains("..")
                            && Sourcetablename.split("\\.").length > 2) {
                        Sourcetablename = Sourcetablename.split("\\.")[Sourcetablename.split("\\.").length - 2] + "." + Sourcetablename.split("\\.")[Sourcetablename.split("\\.").length - 1];
                    }

                    if (Sourcetablename.contains("..")) {
                        String databaseName = Sourcetablename.split("\\..")[0].toUpperCase();
                        String withoutschmetablename = Sourcetablename.split("\\..")[1];

                        for (int i = 0; i < envMap.size(); i++) {
                            String metadatadbName = ((String) envMap.get(i)).split("###")[3].toUpperCase();
                            if (databaseName.equalsIgnoreCase(metadatadbName)) {
                                String Schemas = ((String) envMap.get(i)).split("###")[4];
                                String[] schemas = Schemas.split(",");
                                for (String schema1 : schemas) {
                                    String srctab = schema1 + "." + withoutschmetablename;
                                    updateTableDetails(envMap, srctab, smutill, sysEnvTableDetails, tableColDetails);

                                    if (sysEnvTableDetails.containsKey(srctab)) {
                                        String sourceenvSys = (String) sysEnvTableDetails.get(srctab);
                                        String SystemName = sourceenvSys.split("###")[0];
                                        String environmentName = sourceenvSys.split("###")[1];
                                        mapSPecs.setSourceSystemName(SystemName);
                                        mapSPecs.setSourceSystemEnvironmentName(environmentName);
                                        mapSPecs.setSourceTableName(srctab);

                                        sourcenamesset = false;
                                        addSourceColumnsDetails(mapSPecs, srctab.trim().toUpperCase(), sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
                                    }
                                }
                            }
                        }
                    }
                }
                if (sourcenamesset) {

                    if (Sourcetablename.trim().contains("..")) {

                        Sourcetablename = Sourcetablename.replace("..", "." + fromfileschemaName + ".");
                        Sourcetablename = Sourcetablename.split("\\.")[Sourcetablename.split("\\.").length - 2] + "." + Sourcetablename.split("\\.")[Sourcetablename.split("\\.").length - 1];
                    }
                    sourceNamesSet(Sourcetablename.trim().toUpperCase(), envMap, mapSPecs, mapName, storprocName, subjectName, sysEnvTableDetails, tableColDetails, smutill);
                    addSourceColumnsDetails(mapSPecs, Sourcetablename.trim().toUpperCase(), sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
                }
                String targetTableName = mapSPecs.getTargetTableName();

                if (targetTableName.split("\n").length == 1) {
                    if (targetTableName.contains(".") && !targetTableName.contains("..")
                            && targetTableName.split("\\.").length > 2) {
                        targetTableName = targetTableName.split("\\.")[targetTableName.split("\\.").length - 2] + "." + targetTableName.split("\\.")[targetTableName.split("\\.").length - 1];
                    }

                    if (targetTableName.contains("..")) {
                        String databaseName = targetTableName.split("\\..")[0].toUpperCase();
                        String withoutschmetablename = targetTableName.split("\\..")[1];

                        for (int i = 0; i < envMap.size(); i++) {
                            String metadatadbName = ((String) envMap.get(i)).split("###")[3].toUpperCase();
                            if (databaseName.equalsIgnoreCase(metadatadbName)) {
                                String Schemas = ((String) envMap.get(i)).split("###")[4];
                                String[] schemas = Schemas.split(",");
                                for (String schema1 : schemas) {
                                    String tgttab = schema1 + "." + withoutschmetablename;
                                    updateTableDetails(envMap, tgttab, smutill, sysEnvTableDetails, tableColDetails);

                                    if (sysEnvTableDetails.containsKey(tgttab)) {
                                        String sourceenvSys = (String) sysEnvTableDetails.get(tgttab);
                                        String SystemName = sourceenvSys.split("###")[0];
                                        String environmentName = sourceenvSys.split("###")[1];
                                        mapSPecs.setTargetSystemName(SystemName);
                                        mapSPecs.setTargetSystemEnvironmentName(environmentName);
                                        mapSPecs.setTargetTableName(tgttab);
                                        addTargetColumnsDetails(mapSPecs, tgttab.trim().toUpperCase(), sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
                                        targetnamesset = false;
                                    }
                                }
                            }
                        }
                    }
                }
                if (targetnamesset) {

                    if (targetTableName.trim().contains("..")) {

                        targetTableName = targetTableName.replace("..", "." + fromfileschemaName + ".");
                        targetTableName = targetTableName.split("\\.")[targetTableName.split("\\.").length - 2] + "." + targetTableName.split("\\.")[targetTableName.split("\\.").length - 1];
                    }
                    targetNameSet(targetTableName.trim().toUpperCase(), envMap, mapSPecs, mapName, storprocName, subjectName, sysEnvTableDetails, tableColDetails, smutill);
                    addTargetColumnsDetails(mapSPecs, targetTableName.trim().toUpperCase(), sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
                }
            }

            metadataDesign(mapObj);

            removeDupilcateMapSpecRow(mapObj);
            metadatajsonPath = "";
            folderPath = "";
            return mapObj;
        } catch (Exception ex) {
            ex.printStackTrace();
            LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside getSourceSystem()>>", ex);
            return null;
        }
    }

    public static List<MappingSpecificationRow> updatespecrowforstar(List<MappingSpecificationRow> mapspeclist, List<String> envMap, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        ArrayList<MappingSpecificationRow> rowlist = new ArrayList<MappingSpecificationRow>();
        try {
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = (MappingSpecificationRow) iter.next();
                if (row.getSourceColumnName().equalsIgnoreCase("*")) {
                    String sourceTableName = row.getSourceTableName();
                    if (sourceTableName.split("\n").length == 1
                            && sourceTableName.contains(".")
                            && sourceTableName.split("\\.").length > 2) {
                        sourceTableName = sourceTableName.split("\\.")[sourceTableName.split("\\.").length - 2] + "." + sourceTableName.split("\\.")[sourceTableName.split("\\.").length - 1];
                    }

                    boolean checkingRemoveStarIterator = false;
                    String targetTableName = row.getTargetTableName();
                    Set<String> columnset = new LinkedHashSet<String>();
                    if (tableColDetails.get(sourceTableName) == null
                            && !sourceTableName.toUpperCase().contains("RESULT") && !sourceTableName.toUpperCase().contains("INSERT") && !sourceTableName.toUpperCase().contains("UPDATE") && !sourceTableName.toUpperCase().startsWith("#") && !sourceTableName.toUpperCase().contains("RS-")) {
                        updateTableDetails(envMap, sourceTableName, smutill, sysEnvTableDetails, tableColDetails);
                    }

                    if (tableColDetails.get(sourceTableName) != null) {
                        columnset = ((Map) tableColDetails.get(sourceTableName)).keySet();
                        checkingRemoveStarIterator = true;
                    }

                    columnset.remove("*");
                    for (String column : columnset) {
                        MappingSpecificationRow row1 = new MappingSpecificationRow();
                        row1.setSourceSystemEnvironmentName(row.getSourceSystemEnvironmentName());
                        row1.setTargetSystemEnvironmentName(row.getTargetSystemEnvironmentName());
                        row1.setSourceSystemName(row.getSourceSystemName());
                        row1.setTargetSystemName(row.getTargetSystemName());
                        row1.setSourceTableName(sourceTableName);
                        row1.setTargetTableName(targetTableName);
                        row1.setSourceColumnName(column);
                        row1.setTargetColumnName(column);
                        rowlist.add(row1);
                    }

                    if (checkingRemoveStarIterator) {
                        iter.remove();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return rowlist;
    }

    public static void sourceNamesSet(String Sourcetablename, List<String> envMap, MappingSpecificationRow mapSPecs, String mapName, String storprocName, String folderName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        if (Sourcetablename.split("\n").length > 1) {
            String[] sourcetablecolumn = Sourcetablename.split("\n");
            List<String> sourcesystem = getSourceSystem(sourcetablecolumn, mapName, envMap, mapSPecs, storprocName, folderName, sysEnvTableDetails, tableColDetails, smutill);
            List<String> sourceenv = getSourceEnv(sourcetablecolumn, mapName, envMap, mapSPecs, storprocName, folderName, sysEnvTableDetails, tableColDetails, smutill);
            List<String> sourceTabc = getappendSourceTables(sourcetablecolumn, mapName);
            String sourceSystem = StringUtils.join(sourcesystem, "\n");
            String sourceEnv = StringUtils.join(sourceenv, "\n");
            String Sourcetables = StringUtils.join(sourceTabc, "\n");
            mapSPecs.setSourceSystemEnvironmentName(sourceEnv);
            mapSPecs.setSourceSystemName(sourceSystem);
            mapSPecs.setSourceTableName(Sourcetables);
        } else {
            if (!sysEnvTableDetails.containsKey(Sourcetablename)
                    && !Sourcetablename.toUpperCase().contains("RESULT") && !Sourcetablename.toUpperCase().contains("INSERT") && !Sourcetablename.toUpperCase().contains("UPDATE") && !Sourcetablename.toUpperCase().startsWith("#") && !Sourcetablename.toUpperCase().contains("RS-") && !Sourcetablename.toUpperCase().equalsIgnoreCase(folderName)) {
                updateTableDetails(envMap, Sourcetablename, smutill, sysEnvTableDetails, tableColDetails);
            }

            if (sysEnvTableDetails.containsKey(Sourcetablename)) {
                String sourceenvSys = (String) sysEnvTableDetails.get(Sourcetablename);

                String SystemName = sourceenvSys.split("###")[0];
                String environmentName = sourceenvSys.split("###")[1];
                mapSPecs.setSourceSystemName(SystemName);
                mapSPecs.setSourceSystemEnvironmentName(environmentName);
                mapSPecs.setSourceTableName(Sourcetablename);
            } else if (Sourcetablename.toUpperCase().contains("RESULT_OF_") || Sourcetablename.toUpperCase().contains("INSERT-SELECT") || Sourcetablename.toUpperCase().contains("UPDATE-SELECT") || Sourcetablename.toUpperCase().contains("RS-")) {
                mapSPecs.setSourceTableName("");
                mapSPecs.setSourceTableName(Sourcetablename + "_" + mapName);
            } else {
                mapSPecs.setSourceTableName(Sourcetablename);
            }
        }
    }

    public static void targetNameSet(String Targettablename, List<String> envMap, MappingSpecificationRow mapSPecs, String mapName, String storprocName, String folderName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        if (Targettablename.split("\n").length > 1) {
            String[] tgttablecolumn = Targettablename.split("\n");
            List<String> targetsystem = getTargetSystem(tgttablecolumn, mapName, envMap, mapSPecs, storprocName, folderName, sysEnvTableDetails, tableColDetails, smutill);
            List<String> targeteenv = gettargetEnv(tgttablecolumn, mapName, envMap, mapSPecs, storprocName, folderName, sysEnvTableDetails, tableColDetails, smutill);
            List<String> tgtTabc = getappendSourceTables(tgttablecolumn, mapName);
            String sourceSystem = StringUtils.join(targetsystem, "\n");
            String sourceEnv = StringUtils.join(targeteenv, "\n");
            String tgttab = StringUtils.join(tgtTabc, "\n");
            mapSPecs.setTargetSystemName(sourceSystem);
            mapSPecs.setTargetSystemEnvironmentName(sourceEnv);
            mapSPecs.setTargetTableName(tgttab);
        } else {
            if (!sysEnvTableDetails.containsKey(Targettablename)
                    && !Targettablename.toUpperCase().contains("RESULT") && !Targettablename.toUpperCase().contains("INSERT") && !Targettablename.toUpperCase().contains("UPDATE") && !Targettablename.toUpperCase().startsWith("#") && !Targettablename.toUpperCase().contains("RS-") && !Targettablename.toUpperCase().equalsIgnoreCase(folderName)) {
                updateTableDetails(envMap, Targettablename, smutill, sysEnvTableDetails, tableColDetails);
            }

            if (sysEnvTableDetails.containsKey(Targettablename)) {
                String targetenvSys = (String) sysEnvTableDetails.get(Targettablename);
                String SystemName = targetenvSys.split("###")[0];
                mapSPecs.setTargetSystemName(SystemName);
                String environmentName = targetenvSys.split("###")[1];
                mapSPecs.setTargetSystemEnvironmentName(environmentName);
                mapSPecs.setTargetTableName(Targettablename);
            } else if (Targettablename.toUpperCase().contains("RESULT_OF_") || Targettablename.toUpperCase().contains("INSERT-SELECT") || Targettablename.toUpperCase().contains("UPDATE-SELECT") || Targettablename.toUpperCase().contains("RS-")) {
                mapSPecs.setTargetTableName("");
                mapSPecs.setTargetTableName(Targettablename + "_" + mapName);
            } else {
                mapSPecs.setTargetTableName(Targettablename);
            }
        }
    }

    public static List<String> getSourceSystem(String[] sourcetablename, String mapname, List<String> envMap, MappingSpecificationRow mapSPecs, String storprocName, String folderName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        List<String> sourcesystem = new LinkedList<String>();
        try {
            for (String sourceTab : sourcetablename) {
                if (sourceTab.contains(".")
                        && sourceTab.split("\\.").length > 2) {
                    sourceTab = sourceTab.split("\\.")[sourceTab.split("\\.").length - 2] + "." + sourceTab.split("\\.")[sourceTab.split("\\.").length - 1];
                }

                if (!sysEnvTableDetails.containsKey(sourceTab)
                        && !sourceTab.toUpperCase().contains("RESULT") && !sourceTab.toUpperCase().contains("INSERT") && !sourceTab.toUpperCase().contains("UPDATE") && !sourceTab.toUpperCase().startsWith("#") && !sourceTab.toUpperCase().contains("RS-")) {
                    updateTableDetails(envMap, sourceTab, smutill, sysEnvTableDetails, tableColDetails);
                }

                if (sysEnvTableDetails.containsKey(sourceTab)) {
                    String sourceenvSys = (String) sysEnvTableDetails.get(sourceTab);
                    sourcesystem.add(sourceenvSys.split("###")[0]);
                } else {

                    sourcesystem.add("Oracle");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside getSourceSystem()>>", e);
        }
        return sourcesystem;
    }

    public static List<String> getTargetSystem(String[] targettablename, String mapname, List<String> envMap, MappingSpecificationRow mapSPecs, String storprocName, String folderName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        List<String> tgtsystem = new LinkedList<String>();
        try {
            for (String targetTab : targettablename) {

                if (targetTab.contains(".")
                        && targetTab.split("\\.").length > 2) {
                    targetTab = targetTab.split("\\.")[targetTab.split("\\.").length - 2] + "." + targetTab.split("\\.")[targetTab.split("\\.").length - 1];
                }

                if (!sysEnvTableDetails.containsKey(targetTab)
                        && !targetTab.toUpperCase().contains("RESULT") && !targetTab.toUpperCase().contains("INSERT") && !targetTab.toUpperCase().contains("UPDATE") && !targetTab.toUpperCase().startsWith("#") && !targetTab.toUpperCase().contains("RS-")) {
                    updateTableDetails(envMap, targetTab, smutill, sysEnvTableDetails, tableColDetails);
                }

                if (sysEnvTableDetails.containsKey(targetTab)) {
                    String sourceenvSys = (String) sysEnvTableDetails.get(targetTab);
                    tgtsystem.add(sourceenvSys.split("###")[0]);
                } else {

                    String SystemName = mapSPecs.getTargetSystemName();
                    tgtsystem.add("Oracle");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside getTargetSystem()>>", e);
        }
        return tgtsystem;
    }

    public static List<String> getSourceEnv(String[] sourcetablename, String mapname, List<String> envMap, MappingSpecificationRow mapSPecs, String storprocName, String folderName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        List<String> sourceenv = new LinkedList<String>();
        try {
            for (String sourceTab : sourcetablename) {
                if (sourceTab.contains(".")
                        && sourceTab.split("\\.").length == 3) {
                    sourceTab = sourceTab.split("\\.")[1] + "." + sourceTab.split("\\.")[2];
                }

                if (!sysEnvTableDetails.containsKey(sourceTab)
                        && !sourceTab.toUpperCase().contains("RESULT") && !sourceTab.toUpperCase().contains("INSERT") && !sourceTab.toUpperCase().contains("UPDATE") && !sourceTab.toUpperCase().startsWith("#") && !sourceTab.toUpperCase().contains("RS-")) {
                    updateTableDetails(envMap, sourceTab, smutill, sysEnvTableDetails, tableColDetails);
                }

                if (sysEnvTableDetails.containsKey(sourceTab)) {
                    String sourceenvSys = (String) sysEnvTableDetails.get(sourceTab);
                    sourceenv.add(sourceenvSys.split("###")[1]);
                } else {
                    String envName = mapSPecs.getTargetSystemEnvironmentName();
                    sourceenv.add("SYS");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside getSourceEnv()>>", e);
        }
        return sourceenv;
    }

    public static List<String> gettargetEnv(String[] targettablename, String mapname, List<String> envMap, MappingSpecificationRow mapSPecs, String storprocName, String folderName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, SystemManagerUtil smutill) {
        List<String> targetenv = new LinkedList<String>();
        try {
            for (String targetTab : targettablename) {
                if (targetTab.contains(".")
                        && targetTab.split("\\.").length == 3) {
                    targetTab = targetTab.split("\\.")[1] + "." + targetTab.split("\\.")[2];
                }

                if (!sysEnvTableDetails.containsKey(targetTab)
                        && !targetTab.toUpperCase().contains("RESULT") && !targetTab.toUpperCase().contains("INSERT") && !targetTab.toUpperCase().contains("UPDATE") && !targetTab.toUpperCase().startsWith("#") && !targetTab.toUpperCase().contains("RS-")) {
                    updateTableDetails(envMap, targetTab, smutill, sysEnvTableDetails, tableColDetails);
                }

                if (sysEnvTableDetails.containsKey(targetTab)) {
                    String sourceenvSys = (String) sysEnvTableDetails.get(targetTab);
                    targetenv.add(sourceenvSys.split("###")[1]);
                } else {

                    String envName = mapSPecs.getTargetSystemEnvironmentName();
                    targetenv.add("SYS");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return targetenv;
    }

    public static List<String> getappendSourceTables(String[] sourcetablename, String MapName) {
        List<String> sourcTables = new LinkedList<String>();
        try {
            for (String sourceTab : sourcetablename) {
                if (sourceTab.contains(".")
                        && sourceTab.split("\\.").length > 2) {
                    sourceTab = sourceTab.split("\\.")[sourceTab.split("\\.").length - 2] + "." + sourceTab.split("\\.")[sourceTab.split("\\.").length - 1];
                }

                if (sourceTab.toUpperCase().contains("RESULT_OF_") || sourceTab.toUpperCase().contains("INSERT-SELECT") || sourceTab.toUpperCase().contains("UPDATE-SELECT") || sourceTab.toUpperCase().contains("RS-")) {
                    sourceTab = sourceTab + "_" + MapName;
                }
                sourcTables.add(sourceTab);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sourcTables;
    }

    public static void changeresplitTable(ArrayList<MappingSpecificationRow> mapspeclist) {
        try {
            Set<String> targettabset = new LinkedHashSet<String>();
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = (MappingSpecificationRow) iter.next();
                String targetTabName = row.getTargetTableName();
                String SourceTableName = row.getSourceTableName();
                String[] Sourcetablenamearray = SourceTableName.split("\n");
                String Srctablename = "";
                String TgtTabName = "";
                for (String Sourcetablename : Sourcetablenamearray) {
                    String[] stab = Sourcetablename.split("\\.");
                    if (stab.length >= 2) {
                        Srctablename = stab[stab.length - 2] + "." + stab[stab.length - 1];
                    }
                }
                String[] targetTabNamearray = targetTabName.split("\n");
                for (String TargetTabName : targetTabNamearray) {
                    String[] ttab = TargetTabName.split("\\.");
                    if (ttab.length >= 2) {
                        TgtTabName = ttab[ttab.length - 2] + "." + ttab[ttab.length - 1];
                    }
                }
                if (!Srctablename.isEmpty()) {
                    row.setSourceTableName(Srctablename);
                }
                if (!TgtTabName.isEmpty()) {
                    row.setTargetTableName(TgtTabName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside changeresplitTable()>>", e);
        }
    }

    public static void changeresultofTarget(ArrayList<MappingSpecificationRow> mapspeclist, String subjectName, String fromfileschemaName, String mapName) {
        try {
            Set<String> targettabset = new LinkedHashSet<String>();
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                String srcStatus = "false";
                String tgtStatus = "false";
                MappingSpecificationRow row = (MappingSpecificationRow) iter.next();
                StringBuilder sourcetabsb = new StringBuilder();
                StringBuilder targettabsb = new StringBuilder();
                String targetTabName = row.getTargetTableName().replace("[", "").replace("]", "");
                String SourceTableName = row.getSourceTableName().replace("[", "").replace("]", "");
                String targetColumnName = row.getTargetColumnName().replace("[", "").replace("]", "");
                String sourceColumnName = row.getSourceColumnName().replace("[", "").replace("]", "");
                String[] Sourcetablenamearray = SourceTableName.split("\n");
                for (String Sourcetablename : Sourcetablenamearray) {
                    if (!Sourcetablename.toUpperCase().contains("RESULT") && !Sourcetablename.toUpperCase().contains("INSERT") && !Sourcetablename.toUpperCase().contains("UPDATE") && !Sourcetablename.toUpperCase().startsWith("#") && !Sourcetablename.toUpperCase().contains("RS-") && !Sourcetablename.toUpperCase().equalsIgnoreCase(subjectName)
                            && !Sourcetablename.contains(".") && !"".equals(Sourcetablename)) {
                        if (StringUtils.isNotBlank(fromfileschemaName)) {
                            Sourcetablename = "SYS." + Sourcetablename;
                        }
                        sourcetabsb.append(Sourcetablename).append("\n");
                    }

                    if (Sourcetablename.toUpperCase().contains("#")) {

                        String value = "RESULT_OF_";
                        srcStatus = "true";
                        String mapName1 = "_" + mapName;
                        Sourcetablename = Sourcetablename.replaceAll(value, "");
                        Sourcetablename = Sourcetablename.replaceAll(mapName1, "");
                        Sourcetablename = Sourcetablename.replaceAll("#", "");

                        SourceTableName = Sourcetablename;
                    }
                }

                String[] targetTabNamearray = targetTabName.split("\n");
                for (String TargetTabName : targetTabNamearray) {
                    if (!TargetTabName.toUpperCase().contains("RESULT") && !TargetTabName.toUpperCase().contains("INSERT") && !TargetTabName.toUpperCase().contains("UPDATE") && !TargetTabName.toUpperCase().startsWith("#") && !TargetTabName.toUpperCase().contains("RS-") && !TargetTabName.toUpperCase().equalsIgnoreCase(subjectName)
                            && !TargetTabName.contains(".") && !"".equals(TargetTabName)) {
                        if (StringUtils.isNotBlank(fromfileschemaName)) {
                            TargetTabName = "SYS." + TargetTabName;
                        }
                        targettabsb.append(TargetTabName).append("\n");
                    }

                    if (TargetTabName.toUpperCase().contains("#")) {

                        String value = "RESULT_OF_";
                        String mapName1 = "_" + mapName;
                        tgtStatus = "true";
                        TargetTabName = TargetTabName.replaceAll(mapName1, "");
                        TargetTabName = TargetTabName.replaceAll(value, "");
                        TargetTabName = TargetTabName.replaceAll("#", "");
                        targetTabName = TargetTabName;
                    }
                }

                if (targetTabName.contains("RS") || targetTabName.contains("RESULT_OF_")) {
                    String mapName1 = "_" + mapName;
                    targetTabName = targetTabName.replaceAll(mapName1, "");
                }
                if (SourceTableName.contains("RS") || SourceTableName.contains("RESULT_OF_")) {
                    String mapName1 = "_" + mapName;
                    SourceTableName = SourceTableName.replaceAll(mapName1, "");
                }
                if (!sourcetabsb.toString().isEmpty()) {
                    row.setSourceTableName(sourcetabsb.toString().trim());
                } else {
                    row.setSourceTableName(SourceTableName);
                }
                if (!targettabsb.toString().isEmpty()) {
                    row.setTargetTableName(targettabsb.toString().trim());
                    extreamTargetTableName = targettabsb.toString().trim();
                } else {

                    row.setTargetTableName(targetTabName);
                    extreamTargetTableName = targetTabName;
                }

                row.setSourceColumnName(sourceColumnName);
                row.setTargetColumnName(targetColumnName);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside changeresultofTarget()>>", e);
        }
    }

    public static void removebraces(ArrayList<MappingSpecificationRow> mappingspec) {
        try {
            Iterator<MappingSpecificationRow> iter = mappingspec.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = (MappingSpecificationRow) iter.next();

                if (row.getSourceTableName().contains("[") || row.getSourceTableName().contains("]")) {
                    row.setSourceTableName(row.getSourceTableName().replace("[", "").replace("]", ""));
                }
                if (row.getSourceColumnName().contains("[") || row.getSourceColumnName().contains("]")) {
                    row.setSourceColumnName(row.getSourceColumnName().replace("[", "").replace("]", ""));
                }
                if (row.getTargetTableName().contains("[") || row.getTargetTableName().contains("]")) {
                    row.setTargetTableName(row.getSourceTableName().replace("[", "").replace("]", ""));
                }
                if (row.getTargetColumnName().contains("[") || row.getTargetColumnName().contains("]")) {
                    row.setTargetColumnName(row.getTargetColumnName().replace("[", "").replace("]", ""));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void addTargetColumnsDetails(MappingSpecificationRow mapSPecs, String targettablename, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, Map<String, Map<Integer, SMColumn>> ColsDetails, List<String> envMap, SystemManagerUtil smutill) {
        try {
            if (targettablename.split("\n").length > 1) {
                String targetTable = targettablename.split("\n")[0];
                String targetColumn = mapSPecs.getTargetColumnName().split("\n")[0];
                addTargetColumnsDetails(mapSPecs, targetTable, targetColumn, sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
            } else {
                addTargetColumnsDetails(mapSPecs, targettablename, mapSPecs.getTargetColumnName(), sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
            }
        } catch (Exception e) {
            LOGGER.error("Exception Occured at Syncmetadata_Natixix_V2 inside addSourceColumnsDetails()>>", e);
        }
    }

    private static void addSourceColumnsDetails(MappingSpecificationRow mapSPecs, String Sourcetablename, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, Map<String, Map<Integer, SMColumn>> ColsDetails, List<String> envMap, SystemManagerUtil smutill) {
        try {
            if (Sourcetablename.split("\n").length > 1) {
                String sourceTable = Sourcetablename.split("\n")[0];
                String sourceColumn = mapSPecs.getSourceColumnName().split("\n")[0];
                addSourceColumnsDetails(mapSPecs, sourceTable, sourceColumn, sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
            } else {
                addSourceColumnsDetails(mapSPecs, Sourcetablename, mapSPecs.getSourceColumnName(), sysEnvTableDetails, tableColDetails, ColsDetails, envMap, smutill);
            }
        } catch (Exception e) {
            LOGGER.error("Exception Occured at Syncmetadata_Natixix_V2 inside addSourceColumnsDetails()>>", e);
        }
    }

    private static void addTargetColumnsDetails(MappingSpecificationRow mapSpec, String columnName, String tableName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, Map<String, Map<Integer, SMColumn>> ColsDetails, List<String> sysEnvDetails, SystemManagerUtil smUtil) {
        try {
            SMColumn column = getColDetails(columnName, tableName, sysEnvTableDetails, tableColDetails, ColsDetails, sysEnvDetails, smUtil);
            if (column != null) {
                mapSpec.setTargetColumnDatatype(column.getColumnDatatype());
                mapSpec.setTargetColumnLength(StringUtils.isNumeric(column.getColumnLength()) ? Integer.parseInt(column.getColumnLength()) : 0);
                mapSpec.setTargetColumnPrecision(StringUtils.isNumeric(column.getColumnPrecision()) ? Integer.parseInt(column.getColumnPrecision()) : 0);
                mapSpec.setTargetColumnDefinition(column.getColumnDefinition());
                mapSpec.setTargetColumnNullableFlag(column.isColumnNullableFlag());
                mapSpec.setTargetColumnClass(column.getColumnClass());
                mapSpec.setTargetColumnComments(column.getColumnComments());
                mapSpec.setTargetColumnAlias(column.getColumnAlias());
                mapSpec.setTargetNaturalKeyFlag(column.isNaturalKeyFlag());
                mapSpec.setTargetPrimaryKeyFlag(column.isPrimaryKeyFlag());
                mapSpec.setTargetSDIDescription(column.getSDIDescription());
            }
        } catch (Exception e) {
            LOGGER.error("Exception Occured at Syncmetadata_Natixix_V2 inside addTargetColumnsDetails()>>", e);
        }
    }

    private static SMColumn getColDetails(String columnName, String tableName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, Map<String, Map<Integer, SMColumn>> ColsDetails, List<String> sysEnvDetails, SystemManagerUtil smUtil) {
        MappingSpecificationRow mapSPecs = null;
        if (!tableColDetails.containsKey(tableName)
                && !tableName.toUpperCase().contains("RESULT") && !tableName.toUpperCase().contains("INSERT") && !tableName.toUpperCase().contains("UPDATE") && !tableName.toUpperCase().startsWith("#") && !tableName.toUpperCase().contains("RS-")) {
            updateTableDetails(sysEnvDetails, tableName, smUtil, sysEnvTableDetails, tableColDetails);
        }

        if (tableColDetails.containsKey(tableName)) {
            Map<String, Integer> colDetails = (Map) tableColDetails.get(tableName);
            if (colDetails.containsKey(columnName.trim())) {
                Integer colId = (Integer) colDetails.get(columnName.trim());
                if (!ColsDetails.containsKey(tableName)) {
                    Map<Integer, SMColumn> columnMap = new HashMap<Integer, SMColumn>();
                    ColsDetails.put(tableName, columnMap);
                }
                if (ColsDetails.containsKey(tableName)) {
                    Map<Integer, SMColumn> columnMap = (Map) ColsDetails.get(tableName);
                    if (!columnMap.containsKey(colId)) {
                        try {
                            SMColumn column = smUtil.getColumn(colId.intValue());
                            columnMap.put(colId, column);
                        } catch (Exception e) {
                            columnMap.put(colId, null);
                            LOGGER.error("Exception Occured at Syncmetadata_Natixix_V2 inside updateColDetails()>>", e);
                        }
                    }

                    return (SMColumn) columnMap.get(colId);
                }
            }
        }
        return null;
    }

    private static void addSourceColumnsDetails(MappingSpecificationRow mapSpec, String columnName, String tableName, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails, Map<String, Map<Integer, SMColumn>> ColsDetails, List<String> sysEnvDetails, SystemManagerUtil smUtil) {
        try {
            SMColumn column = getColDetails(columnName, tableName, sysEnvTableDetails, tableColDetails, ColsDetails, sysEnvDetails, smUtil);
            if (column != null) {
                mapSpec.setSourceColumnDatatype(column.getColumnDatatype());
                mapSpec.setSourceColumnLength(StringUtils.isNumeric(column.getColumnLength()) ? Integer.parseInt(column.getColumnLength()) : 0);
                mapSpec.setSourceColumnPrecision(StringUtils.isNumeric(column.getColumnPrecision()) ? Integer.parseInt(column.getColumnPrecision()) : 0);
                mapSpec.setSourceColumnDBDefaultValue(column.getColumnDBDefaultValue());
                mapSpec.setSourceColumnDefinition(column.getColumnDefinition());
                mapSpec.setSourceColumnIdentityFlag(column.isColumnIdentityFlag());
                mapSpec.setSourceColumnNullableFlag(column.isColumnNullableFlag());
                mapSpec.setSourceColumnClass(column.getColumnClass());
                mapSpec.setSourceColumnComments(column.getColumnComments());
                mapSpec.setSourceColumnAlias(column.getColumnAlias());
                mapSpec.setSourceNaturalKeyFlag(column.isNaturalKeyFlag());
                mapSpec.setSourcePrimaryKeyFlag(column.isPrimaryKeyFlag());
                mapSpec.setSourceMaximumValue(StringUtils.isNumeric(column.getMaximumValue()) ? Integer.parseInt(column.getMaximumValue()) : 0);
                mapSpec.setSourceMinimumValue(StringUtils.isNumeric(column.getMinimumValue()) ? Integer.parseInt(column.getMinimumValue()) : 0);
                mapSpec.setSourceSDIDescription(column.getSDIDescription());
            }
        } catch (Exception e) {
            LOGGER.error("Exception Occured at Syncmetadata_Natixix_V2 inside addSourceColumnsDetails()>>", e);
        }
    }

    public static void updateTableDetails(List<String> sysEnvDetails, String tableName, SystemManagerUtil smUtil, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails) {
        Map<String, Integer> cols = new HashMap<String, Integer>();
        for (int i = 0; i < sysEnvDetails.size(); i++) {
            String[] sysEnvDetail = ((String) sysEnvDetails.get(i)).split("###");
            try {
                int tableId = smUtil.getTableId(sysEnvDetail[0], sysEnvDetail[1], tableName);
                if (tableId != -1) {
                    List<SMColumn> colList = smUtil.getColumns(tableId);
                    colList.stream().forEach(col -> {
                        cols.put(col.getColumnName(), Integer.valueOf(col.getColumnId()));
                        colDataType.put(col.getColumnName() + "#" + sysEnvDetail[0] + "#" + sysEnvDetail[1], col.getColumnDatatype());
                    });
                    tableColDetails.put(tableName, cols);
                    sysEnvTableDetails.put(tableName, (String) sysEnvDetails.get(i) + "###" + tableId);

                    break;
                }
            } catch (Exception e) {
                LOGGER.error("Exception Occured at Syncmetadata_Zovio_V2 inside updateTableDetails()>>", e);
            }
        }
    }

    public static void removeExtradots(ArrayList<MappingSpecificationRow> mapspeclist, String schema, List<String> envMap) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        while (iter.hasNext()) {
            MappingSpecificationRow row = (MappingSpecificationRow) iter.next();
            String targetTabName = row.getTargetTableName().replace("[", "").replace("]", "");
            String SourceTableName = row.getSourceTableName().replace("[", "").replace("]", "");
            if (SourceTableName.startsWith(".")) {
                SourceTableName = SourceTableName.replace(".", "");
                row.setSourceTableName(SourceTableName);
            }

            if (targetTabName.startsWith(".")) {
                targetTabName = targetTabName.replace(".", "");
                row.setTargetTableName(targetTabName);
            }
        }
    }

    public static Set<String> gettingInsertselectColumns(String sourceTableName, List<MappingSpecificationRow> mapspeclist) {
        Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
        Set<String> insertcolList = new HashSet<String>();
        while (iter.hasNext()) {
            MappingSpecificationRow row = (MappingSpecificationRow) iter.next();

            String targetTabName = row.getTargetTableName().replace("[", "").replace("]", "");
            String srceTableName = row.getSourceTableName().replace("[", "").replace("]", "");
            if (sourceTableName.equalsIgnoreCase(targetTabName)) {
                String srcColumnName = row.getSourceColumnName();
                insertcolList.add(srcColumnName);
            }
        }
        return insertcolList;
    }

    public static List<MappingSpecificationRow> settingstarColsofInsert(List<MappingSpecificationRow> mapspeclist) {
        ArrayList<MappingSpecificationRow> rowlist = new ArrayList<MappingSpecificationRow>();
        try {
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = (MappingSpecificationRow) iter.next();
                if (row.getSourceColumnName().equalsIgnoreCase("*")) {
                    String sourceTableName = row.getSourceTableName();
                    String targetTableName = row.getTargetTableName();
                    if (sourceTableName.toUpperCase().contains("RESULT") || sourceTableName.toUpperCase().contains("INSERT") || sourceTableName.toUpperCase().contains("UPDATE") || sourceTableName.toUpperCase().startsWith("#") || sourceTableName.toUpperCase().contains("RS-")) {
                        Set<String> insertcolList = gettingInsertselectColumns(sourceTableName, mapspeclist);
                        for (String column : insertcolList) {
                            MappingSpecificationRow row2 = new MappingSpecificationRow();
                            row2.setSourceSystemEnvironmentName(row.getSourceSystemEnvironmentName());
                            row2.setTargetSystemEnvironmentName(row.getTargetSystemEnvironmentName());
                            row2.setSourceSystemName(row.getSourceSystemName());
                            row2.setTargetSystemName(row.getTargetSystemName());
                            row2.setSourceTableName(sourceTableName);
                            row2.setTargetTableName(targetTableName);
                            row2.setSourceColumnName(column);
                            row2.setTargetColumnName(column);
                            rowlist.add(row2);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowlist;
    }

    public static void removestarcolumspec(List<MappingSpecificationRow> mapspeclist) {
        try {
            Map<String, String> starmap = new LinkedHashMap<String, String>();
            Map<String, String> normalmap = new LinkedHashMap<String, String>();
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row = (MappingSpecificationRow) iter.next();
                if (row.getSourceColumnName().equalsIgnoreCase("*")) {
                    starmap.put(row.getSourceTableName().toUpperCase().trim(), row.getSourceColumnName().toUpperCase().trim());
                } else {
                    normalmap.put(row.getSourceTableName().toUpperCase().trim(), row.getSourceColumnName().toUpperCase().trim());
                }
                if (row.getTargetTableName().equalsIgnoreCase("") && row.getTargetColumnName().equalsIgnoreCase("") && row.getBusinessRule().equalsIgnoreCase("")) {
                    iter.remove();
                }
            }
            forRemovingStar(mapspeclist, starmap, normalmap);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void forRemovingStar(List<MappingSpecificationRow> mapspeclist, Map<String, String> starmap, Map<String, String> normalmap) {
        try {
            Iterator<MappingSpecificationRow> iter = mapspeclist.iterator();
            while (iter.hasNext()) {
                MappingSpecificationRow row1 = (MappingSpecificationRow) iter.next();
                if (row1.getSourceColumnName().equalsIgnoreCase("*")
                        && normalmap.containsKey(row1.getSourceTableName().toUpperCase())
                        && starmap.containsKey(row1.getSourceTableName().toUpperCase())) {
                    iter.remove();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String preCreatingMapVersion(ArrayList<MappingSpecificationRow> mappingSpecificationRowsList, int projectId, String mappingName, KeyValueUtil keyValueUtil, MappingManagerUtil mappingManagerUtil, int subjectId) {
        Mapping latestMappingObj = null;
        ObjectMapper mapper = new ObjectMapper();
        String resultStatus = null;
        return creatingMapVersion(projectId, mappingName, subjectId, mappingSpecificationRowsList, keyValueUtil, mappingManagerUtil);
    }

    public static String creatingMapVersion(int projectId, String mappingName, int parentSubectId, ArrayList<MappingSpecificationRow> mapspecList, KeyValueUtil keyValueUtil, MappingManagerUtil mappingManagerUtil) {
        Mapping latestMappingObj = null;
        List<Float> latestMappingVersion = null;
        Float updateMappingVersion = Float.valueOf(0.0F);
        RequestStatus resultStatus = null;
        StringBuilder statusbuilder = new StringBuilder();
        try {
            latestMappingVersion = getMappingVersions(parentSubectId, mappingName, mappingManagerUtil);
            updateMappingVersion = (Float) latestMappingVersion.get(latestMappingVersion.size() - 1);
            Mapping mappingObj = mappingManagerUtil.getMapping(parentSubectId, Node.NodeType.MM_SUBJECT, mappingName, updateMappingVersion.floatValue());
            int mappId = mappingObj.getMappingId();
            mappingObj.setProjectId(projectId);
            mappingObj.setSubjectId(parentSubectId);
            mappingObj.setMappingId(mappId);
            mappingObj.setChangedDescription("Mapping " + mappingName + " changed! as Version Done: " + updateMappingVersion);
            String status = mappingManagerUtil.versionMapping(mappingObj).getStatusMessage();
            statusbuilder.append(mappingName + "\n\n" + status + "\n\n");
            List<Float> latestMapVersion = getMappingVersions(parentSubectId, mappingName, mappingManagerUtil);
            Float latestMapV = (Float) latestMapVersion.get(latestMapVersion.size() - 1);
            latestMappingObj = mappingManagerUtil.getMapping(parentSubectId, Node.NodeType.MM_SUBJECT, mappingName, latestMapV.floatValue());
            int latestMapId = latestMappingObj.getMappingId();
            mappingManagerUtil.deleteMappingSpecifications(latestMapId);
            resultStatus = mappingManagerUtil.addMappingSpecifications(latestMapId, mapspecList);
            String msg = resultStatus.getStatusMessage();
            statusbuilder.append(msg + "\n\n" + status + "\n\n");
        } catch (Exception e) {
            StringWriter exceptionLog = new StringWriter();
            e.printStackTrace(new PrintWriter(exceptionLog));
        }
        return statusbuilder.toString();
    }

    public static List<Float> getMappingVersions(int subjectId, String mapName, MappingManagerUtil mappingManagerUtil) {
        List<Float> mapVersionList = new ArrayList<Float>();
        try {
            ArrayList<Mapping> mappings = mappingManagerUtil.getMappings(subjectId, Node.NodeType.MM_SUBJECT);

            if (!mappings.isEmpty()) {
                for (int map = 0; map < mappings.size(); map++) {
                    String mappingName = ((Mapping) mappings.get(map)).getMappingName();
                    float mappingVersion = ((Mapping) mappings.get(map)).getMappingSpecVersion();
                    if (mapName.equalsIgnoreCase(mappingName)) {
                        mapVersionList.add(Float.valueOf(mappingVersion));
                    }
                }
            }
        } catch (Exception e) {
            if ("Invalid ProjectId".equalsIgnoreCase(e.getMessage()));
        }

        return mapVersionList;
    }

    public static String addMapSpecificationsForFullLoadType(int mapId, ArrayList<MappingSpecificationRow> mappingSpecificationRowsList, MappingManagerUtil mappingManagerUtil) {
        RequestStatus resultStatus = null;

        resultStatus = mappingManagerUtil.deleteMappingSpecifications(mapId);
        resultStatus = mappingManagerUtil.addMappingSpecifications(mapId, mappingSpecificationRowsList);
        return resultStatus.getStatusMessage();
    }

    public static String gettingdatabaseNameFromQueryUsingUseWord(String query) {
        String databaseName = "";
        String pattern = "USE";
        if (query.toUpperCase().contains("USE")) {
            try {
                int i = 0;
                String[] linearr = query.split("\n");
                for (String line : linearr) {
                    line = line.replaceAll("\\ + ", "\\ ").trim();
                    if (line.contains("USE")) {
                        int index = line.indexOf("USE");
                        if (line.indexOf(" ", index + pattern.length() + 1) != -1) {
                            line = line.substring(index + pattern.length() + 1, line.indexOf(" ", index + pattern.length() + 1));
                        } else {
                            line = line.substring(line.indexOf(" ", index + pattern.length()));
                        }
                        line = line.replace("[", "").replace("]", "");
                        databaseName = line.toUpperCase().trim();
                    }
                    if (StringUtils.isNotEmpty(databaseName)) {
                        break;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return databaseName;
    }

    private static void metadataDesign(List<Mapping> mapObj) {
        ArrayList<MappingSpecificationRow> mapSPecsLists = ((Mapping) mapObj.get(0)).getMappingSpecifications();
        for (MappingSpecificationRow row : mapSPecsLists) {
            String srcsysName = row.getSourceSystemName();
            String srcenvName = row.getSourceSystemEnvironmentName();

            String tgtsysName = row.getTargetSystemName();
            String tgtenvName = row.getTargetSystemEnvironmentName();
            String tgtTableName = row.getTargetTableName();
            if (srcsysName == "" || srcenvName == "" || srcsysName.trim().length() == 0) {
                srcsysName = "Oracle";
                srcenvName = "Sys";
                row.setSourceSystemName(srcsysName);
                row.setSourceSystemEnvironmentName(srcenvName);
            }
            if (tgtsysName == "" || tgtenvName == "" || tgtsysName.trim().length() == 0) {
                tgtsysName = "Oracle";
                tgtenvName = "Sys";
                row.setTargetSystemName(tgtsysName);
                row.setTargetSystemEnvironmentName(tgtenvName);
            }

            if (tgtTableName.toUpperCase().contains(extreamTargetTableName.toUpperCase()) && tgtTableName.toUpperCase().contains("RS")) {
                row.setTargetTableName(((Mapping) mapObj.get(0)).getMappingName());
            }
        }
    }

    public static String addMappingSpecDoc1(MappingManagerUtil mappingManagerUtil, String mapName, int mapID, String filePath) {
        File f1 = new File(filePath);
        String type = f1.getName().split("\\.")[1];
        Document mapDoc = new Document();
        mapDoc.setDocumentName(mapName);
        mapDoc.setDocumentType(type);
        mapDoc.setDocumentIntendedPurpose("Query Extract");
        mapDoc.setDocumentOwner("Admin");
        mapDoc.setDocumentObject(filePath);
        mapDoc.setDocumentLink(" ");
        mapDoc.setDocumentReference(" ");
        mapDoc.setApprovalRequired(true);
        Date today = new Date();
        mapDoc.setDocumentApprovedDate(today);
        mapDoc.setDocumentStatus("Approved");

        RequestStatus req = mappingManagerUtil.addMappingDocument(mapID, mapDoc);
        return req.getStatusMessage();
    }

    private static void modificationOfExtreamtarget(List<Mapping> mapObj, String mapName) {
        ArrayList<MappingSpecificationRow> mapRow = ((Mapping) mapObj.get(0)).getMappingSpecifications();
        String FinalTableName = "";
        Set<String> tableName = ExtreamSourceAndExtreamTarget.getExtremeTargetSet(mapRow);
        for (String tableName1 : tableName) {
            FinalTableName = tableName1;
        }
        for (MappingSpecificationRow row : mapRow) {
            String targetTableName = row.getTargetTableName();

            if (FinalTableName.toUpperCase().equalsIgnoreCase(targetTableName.toUpperCase())) {
                row.setTargetTableName(mapName);
            }
        }
    }

    private static void removeDupilcateMapSpecRow(List<Mapping> mapObj) {
        ArrayList<MappingSpecificationRow> mapRow = ((Mapping) mapObj.get(0)).getMappingSpecifications();
        String sqlText = ((Mapping) mapObj.get(0)).getSourceExtractQuery();
        ArrayList<MappingSpecificationRow> mapSpecRows = new ArrayList<MappingSpecificationRow>();
        LinkedHashSet<String> mappingspec = new LinkedHashSet<String>();
        for (MappingSpecificationRow e : mapRow) {
            String srcSystemName = e.getSourceSystemName().toUpperCase().trim();
            String srcEnvName = e.getSourceSystemEnvironmentName().toUpperCase().trim();
            String sourceTableName = e.getSourceTableName().toUpperCase().trim();
            String sourceColumnName = e.getSourceColumnName().toUpperCase().trim();

            String tgtSystemName = e.getTargetSystemName().toUpperCase().trim();
            String tgtEnvName = e.getTargetSystemEnvironmentName().toUpperCase().trim();
            String targetTableName = e.getTargetTableName().toUpperCase().trim();
            String targetColumnName = e.getTargetColumnName().toUpperCase().trim();
            String businessRule = e.getBusinessRule().toUpperCase().trim();
            if (businessRule != "") {
                mappingspec.add(srcSystemName + "#" + srcEnvName + "#" + sourceTableName + "#" + sourceColumnName + "#" + tgtSystemName + "#" + tgtEnvName + "#" + targetTableName + "#" + targetColumnName + "#" + businessRule);
                continue;
            }
            mappingspec.add(srcSystemName + "#" + srcEnvName + "#" + sourceTableName + "#" + sourceColumnName + "#" + tgtSystemName + "#" + tgtEnvName + "#" + targetTableName + "#" + targetColumnName);
        }

        for (String name : mappingspec) {
            MappingSpecificationRow mappingSpecificationRow = new MappingSpecificationRow();
            mappingSpecificationRow.setSourceSystemName(name.split("\\#")[0]);
            mappingSpecificationRow.setSourceSystemEnvironmentName(name.split("\\#")[1]);
            mappingSpecificationRow.setSourceTableName(name.split("\\#")[2]);
            String sourceColumnName = name.split("\\#")[3];
            String sourceColumnDt = "";
            if (colDataType.containsKey(sourceColumnName.trim() + "#" + name.split("\\#")[0] + "#" + name.split("\\#")[1])) {
                sourceColumnDt = (String) colDataType.get(sourceColumnName.trim() + "#" + name.split("\\#")[0] + "#" + name.split("\\#")[1]);
                mappingSpecificationRow.setSourceColumnName(name.split("\\#")[3]);
                mappingSpecificationRow.setSourceColumnDatatype(sourceColumnDt);
            } else {
                mappingSpecificationRow.setSourceColumnName(name.split("\\#")[3]);
            }

            mappingSpecificationRow.setTargetSystemName(name.split("\\#")[4]);
            mappingSpecificationRow.setTargetSystemEnvironmentName(name.split("\\#")[5]);
            mappingSpecificationRow.setTargetTableName(name.split("\\#")[6]);

            String tgtColumnName = name.split("\\#")[7];
            String tgtColumnDt = "";
            if (colDataType.containsKey(tgtColumnName.trim() + "#" + name.split("\\#")[4] + "#" + name.split("\\#")[5])) {
                tgtColumnDt = (String) colDataType.get(tgtColumnName.trim() + "#" + name.split("\\#")[4] + "#" + name.split("\\#")[5]);
                mappingSpecificationRow.setTargetColumnName(name.split("\\#")[7]);
                mappingSpecificationRow.setTargetColumnDatatype(tgtColumnDt);
            } else {
                mappingSpecificationRow.setTargetColumnName(name.split("\\#")[7]);
            }
            try {
                mappingSpecificationRow.setBusinessRule(name.split("\\#")[8]);
                mapSpecRows.add(mappingSpecificationRow);
            } catch (Exception e) {
                mapSpecRows.add(mappingSpecificationRow);
            }
        }

        Mapping map = new Mapping();
        map.setMappingSpecifications(mapSpecRows);
        map.setSourceExtractQuery(sqlText);
        mapObj.clear();
        mapObj.add(map);
    }

    private static List<String> getAllEnviroment(String jsonMetadatapath, String folder) {
        List<String> details = new ArrayList<String>();
        try {
            File value = new File(jsonMetadatapath + folder);
            File[] fileList = value.listFiles();

            for (int i = 0; i < fileList.length; i++) {
                String fileName = fileList[i].getName();
                fileName = fileName.replaceAll(".json", "");
                if (fileName.contains("__")) {
                    String systemName = fileName.split("\\__")[0];
                    String envName = fileName.split("\\__")[1];

                    details.add(systemName + "###" + envName);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static void moveFileToArchive(String archivepath, String sourcepath, StringBuilder sb) {
        File arcFile = new File(archivepath);
        File srcFile = new File(sourcepath);
        File[] arr = srcFile.listFiles();

        if (arr != null) {
            for (int i = 0; i < arr.length; i++) {
                try {
                    String archPath = null;
                    String value = null;
                    if (archivepath.contains("/")) {
                        archPath = archivepath + "\\" + srcFile.getName().replaceAll("\\\\", "");
                        value = archPath.split("\\\\")[1].replaceAll("\\\\", "");
                        archPath = archivepath + "/" + value;
                        File createFile = new File(archPath);
                        Path path = Files.move(Paths.get(sourcepath, new String[0]), Paths.get(archPath, new String[0]), new java.nio.file.CopyOption[0]);
                        //sb.append("Loaction=>"+archPath+"======"+value);
                    } else {
                        File createFile = new File(archivepath + "\\" + srcFile.getName().replaceAll("\\\\", ""));

                        Path path = Files.move(Paths.get(sourcepath, new String[0]), Paths.get(archivepath + "\\" + srcFile.getName().replaceAll("\\\\", ""), new String[0]), new java.nio.file.CopyOption[0]);
                        //sb.append(archivepath + "\\" + srcFile.getName().replaceAll("\\\\",""));
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                    //Logger.getLogger(Syncmetadata_AF_V2_Oracle.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            try {
                String archPath = null;
                String value = null;
                if (archivepath.contains("/")) {
                    archPath = archivepath + "\\" + srcFile.getName().replaceAll("\\\\", "");
                    value = archPath.split("\\\\")[1].replaceAll("\\\\", "");
                    archPath = archivepath + "/" + value;
                    File createFile = new File(archPath);
                    Path path = Files.move(Paths.get(sourcepath, new String[0]), Paths.get(archPath, new String[0]), new java.nio.file.CopyOption[0]);
                    //sb.append("Loaction=>"+archPath+"======"+value);
                } else {
                    File createFile = new File(archivepath + "\\" + srcFile.getName().replaceAll("\\\\", ""));

                    Path path = Files.move(Paths.get(sourcepath, new String[0]), Paths.get(archivepath + "\\" + srcFile.getName().replaceAll("\\\\", ""), new String[0]), new java.nio.file.CopyOption[0]);
                    //sb.append(archivepath + "\\" + srcFile.getName().replaceAll("\\\\",""));
                }

            } catch (IOException ex) {
                ex.printStackTrace();
                //Logger.getLogger(Syncmetadata_AF_V2_Oracle.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void deleteFile(String filepath, StringBuilder sb) {
        File delFile = new File(filepath);
        delFile.delete();

    }

    public static void inputOptionDetails(HashMap<String, String> details, StringBuilder logger) {
        int keyLength = 30;
        String status = "false";
        logger.append("Log Status").append("\n").append("----------------").append("\n").append("Input Parameters").append("\n").append("----------------").append("\n");
        try {

            for (Map.Entry<String, String> entry : details.entrySet()) {
                String inputOP = (String) entry.getKey();
                String value = (String) entry.getValue();
                if (inputOP.equalsIgnoreCase("Log File Path") && value.contains("/")) {
                    status = "true";
                }
                if (inputOP.equalsIgnoreCase("Metadata JSON Path") && status.equalsIgnoreCase("true")) {
                    value = value.replaceAll("\\\\", "/");
                }
                logger.append(inputOP + "    = " + value);
                logger.append("\n");
            }

            logger.append("----------------").append("\n").append("Execution Status").append("\n").append("----------------").append("\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void mappingCreation(StringBuffer sb, StringBuilder logger) {
        String[] stArray = sb.toString().split("\n");
        logger.append(stArray.length).append(" ").append(stArray[0]).append("\n");
    }

    public static void timeStamp(long startTime, long endTime, StringBuilder logger) {
        try {
            logger.append("----------------").append("\n").append(" ").append("\n").append("----------------").append("\n");

            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            Date stresult = new Date(startTime);
            Date endresult = new Date(endTime);

            String stdate1 = simple.format(stresult);
            String enDate1 = simple.format(endresult);

            Date d1 = null;
            Date d2 = null;

            d1 = simple.parse(stdate1);
            d2 = simple.parse(enDate1);

            long diff = d2.getTime() - d1.getTime();
            long diffSeconds = diff / 1000L;
            long diffMinutes = diff / 60000L;
            long diffHours = diff / 3600000L;

            SimpleDateFormat sec = new SimpleDateFormat("ss");
            SimpleDateFormat min = new SimpleDateFormat("mm");
            SimpleDateFormat hr = new SimpleDateFormat("hh");

            String sec1 = Long.toString(diffSeconds);
            String min1 = Long.toString(diffMinutes);
            String hr1 = Long.toString(diffHours);

            logger.append("Start Time           : ").append(stdate1).append("\n");
            logger.append("End Time             : ").append(enDate1).append("\n");

        } catch (ParseException ex) {
            //Logger.getLogger(Syncmetadata_AF_V2_Oracle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static String modifyFilePath(String filePath) {
        try {
            if (filePath.endsWith("\\")) {
                return filePath.substring(0, filePath.length() - 1);
            }
            if (filePath.endsWith("/")) {
                return filePath.substring(0, filePath.length() - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return filePath;
    }

    public static String getLogTimeStamp() {
        Long endValue = System.currentTimeMillis();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date endresult = new Date(endValue);

        String stdate1 = simple.format(endresult);
        stdate1 = stdate1.replaceAll("[^a-zA-Z0-9]", " ");
        stdate1 = stdate1.replaceAll(" ", "");
        return "_" + stdate1;
    }

    public static void syncMetadataFormJson(SystemManagerUtil smUtil, String srcTableName, String jsonMetadatapath, MappingSpecificationRow mapSPecs, String sqlfilepath, Map<String, String> sysEnvTableDetails, Map<String, Map<String, Integer>> tableColDetails) {
        FileReader reader1 = null;
        String systemName1 = "";
        String envName1 = "";
        Map<String, Integer> cols = new HashMap<String, Integer>();
        try {
            String serverDetails = getServerDetailsFormPath(sqlfilepath);

            reader1 = new FileReader(jsonMetadatapath + "\\" + serverDetails + ".json");

            Object obj = (new JSONParser()).parse(reader1);
            JSONArray jo = (JSONArray) obj;

            for (int i = 0; i < jo.size(); i++) {
                JSONObject jo1 = (JSONObject) jo.get(i);

                systemName1 = (String) jo1.get("SystemName");
                envName1 = (String) jo1.get("EnvironmentName");
            }
            String finalDetails = systemName1 + "###" + envName1;
            if (reader1 != null) {
                int tableId = smUtil.getTableId(systemName1, envName1, srcTableName);
                if (tableId != -1) {
                    List<SMColumn> colList = smUtil.getColumns(tableId);
                    for (SMColumn col : colList) {
                        cols.put(col.getColumnName(), Integer.valueOf(col.getColumnId()));
                        colDataType.put(col.getColumnName() + "#" + finalDetails.split("\\###")[0].toUpperCase() + "#" + finalDetails.split("\\###")[1].toUpperCase(), col.getColumnDatatype());
                    }

                    tableColDetails.put(srcTableName, cols);
                    sysEnvTableDetails.put(srcTableName, finalDetails + "###" + tableId);
                }

            }

        } catch (Exception ex) {
            ex.printStackTrace();
            //Logger.getLogger(Syncmetadata_Zovio_V2.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
        }
    }

    private static String getServerDetailsFormPath(String sqlfilepath) {
        String[] s1 = sqlfilepath.split("\\\\");

        String serverName = s1[s1.length - 4];
        String dbName = s1[s1.length - 3];
        String finalData = serverName + "_" + dbName;
        return finalData.toUpperCase();
    }

    public static String addSlashtoFile(String path) {
        String path1 = "";
        if (path.contains("/")) {
            path = path.replace("/", "\\");
        }
        if (path.endsWith("\\") && !path.equals("")) {
            path1 = path;
        } else if (!path.endsWith("\\") && !path.equals("") && !path.contains("/")) {
            path1 = path + "\\";
        } else if (!path.endsWith("/") && !path.equals("") && !path.contains("\\")) {
            path1 = path + "/";
        } else if (path.endsWith("/") && !path.equals("") && !path.contains("\\")) {
            path1 = path;
        }
        return path1;
    }
/*
    public static List<MappingSpecificationRow> metadataDesign1(List<MappingSpecificationRow> mapSPecsLists, String mapName, SystemManagerUtil smutil, StringBuilder forMetadataSynp) {
        for (MappingSpecificationRow row : mapSPecsLists) {
            extreamTargetTableName = row.getTargetTableName();
        }

        for (MappingSpecificationRow row : mapSPecsLists) {
            String srcsysName = row.getSourceSystemName();
            String srcenvName = row.getSourceSystemEnvironmentName();
            String srcTabName = row.getSourceTableName();
            String srcColName = row.getSourceColumnName();

            String tgtsysName = row.getTargetSystemName();
            String tgtenvName = row.getTargetSystemEnvironmentName();
            String tgtTableName = row.getTargetTableName();
            String tgtColName = row.getTargetColumnName();
            if (!srcsysName.contains("Oracle") && forMetadataSynp.toString().length() == 0) {
                forMetadataSynp.append("MetaData Synup Done");
            }
            if (!srcTabName.contains("UPDATE-SET-") && !srcTabName.contains("INSERT-SELECT-") && !srcsysName.contains("Oracle")) {
                try {
                    int srcColId = smutil.getColumnId(srcsysName, srcenvName, srcTabName, srcColName);
                    if (srcColId > 0) {
                        SMColumn colObj = smutil.getColumn(srcColId);
                        String srcColDataType = colObj.getColumnDatatype();
                        row.setSourceColumnDatatype(srcColDataType);

                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

            if (!tgtTableName.contains("UPDATE-SET-") && !tgtTableName.contains("INSERT-SELECT-") && !tgtsysName.contains("Oracle")) {
                try {
                    int tgtColId = smutil.getColumnId(tgtsysName, tgtenvName, tgtTableName, tgtColName);
                    if (tgtColId > 0) {
                        SMColumn colObj = smutil.getColumn(tgtColId);
                        String tgtColDataType = colObj.getColumnDatatype();
                        row.setTargetColumnDatatype(tgtColDataType);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

            if (tgtTableName.toUpperCase().contains(extreamTargetTableName.toUpperCase()) && tgtTableName.toUpperCase().contains("RS")) {
                row.setTargetTableName(mapName);

            }
        }
        extreamTargetTableName = "";
        return mapSPecsLists;
    }
*/
    public static List<MappingSpecificationRow> metadataDesign1(List<MappingSpecificationRow> mapSPecsLists, String mapName,SystemManagerUtil smutil, StringBuilder forMetadataSynp) {
    for (MappingSpecificationRow row : mapSPecsLists) {
      extreamTargetTableName = row.getTargetTableName();
    }
    
    for (MappingSpecificationRow row : mapSPecsLists) {
      String srcsysName = row.getSourceSystemName();
      String srcenvName = row.getSourceSystemEnvironmentName();
      
      String tgtsysName = row.getTargetSystemName();
      String tgtenvName = row.getTargetSystemEnvironmentName();
      String tgtTableName = row.getTargetTableName();
      if (tgtTableName.toUpperCase().contains(extreamTargetTableName.toUpperCase()) && tgtTableName.toUpperCase().contains("RS")) {
        row.setTargetTableName(mapName);
      }
    } 
    
    extreamTargetTableName = "";
    return mapSPecsLists;
  }
    
    public static String designComplectLogFile(StringBuilder forMappingCreation, StringBuilder forMappingCreationFailed,
            StringBuilder forSubjectCreation,
            StringBuilder forProjcetCreation, LinkedHashMap<String, String> inputDetails, int totalFileCount, String logFileName, long stTime,StringBuilder forWrongFormat) {
        String value = "pps";
        
        creatingLogDetailsForCat.append("Start Time=" + inputDetails.get("TimeStamp"));

        creatingLogDetailsForCat.append("\n");

        createHeaderDesign(logDetails, inputDetails, forProjcetCreation);

        String logFilePath = inputDetails.get("Log File Path");
        logFilePath = modifyFilePath(logFilePath);
        creationLogForSubjects(logDetails, forSubjectCreation);
        creationLogForMappingCreation(logDetails, forMappingCreation, inputDetails);
        if(forWrongFormat.toString().length()!=0){
            creationLogForWrongFormat(logDetails,forWrongFormat);
        }
        if (forMappingCreationFailed.length() != 0) {
            creationLogForFailedMapping(logDetails, forMappingCreationFailed);
        }
        creatingFotterForLog(inputDetails, logDetails, totalFileCount, totalMappingCount, totalNumberOfSub, totalProjectCount, stTime);
        File logFile = new File(logFilePath + "/" + logFileName + "_" + getLogTimestamp() + ".txt");

        try {

            FileUtils.writeStringToFile(logFile, logDetails.toString());

//            FileWriter myWriter = new FileWriter(logFile);
//            myWriter.write(logDetails.toString());
//            myWriter.write(log);
            creatingLogDetailsForCat.append("\n");
            return creatingLogDetailsForCat.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getLogTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return sdf.format(date);
    }

    public static String getLogDetailsTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return sdf.format(date);
    }

    private static void creationLogForSubjects(StringBuilder logDetails, StringBuilder forSubjectCreation) {

        if (forSubjectCreation.length() != 0) {
            String subLogDetalis = forSubjectCreation.toString();

            String[] subDetails = subLogDetalis.split("\\n");

            for (int k = 0; k < subDetails.length; k++) {
                totalNumberOfSub++;
                String subName = subDetails[k].split("#")[0];
                String timeStamp = subDetails[k].split("#")[1];
                logDetails.append("[" + timeStamp + "]::Info::DIS::API_Subject_creation_Call=" + '"' + subName + '"' + "::API_Response=" + '"' + "Subject Created" + '"' + "\n");
            }
        } else {
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Info::DIS::API_Subject_creation_Call=" + '"' + +'"' + "::API_Response=" + '"' + "Subject Already Exist" + '"' + "\n");
        }

    }

    private static void creationLogForMappingCreation(StringBuilder logDetails, StringBuilder forMappingCreation, LinkedHashMap<String, String> inputDetails) {
        try {
            String mappingCreationStatus = forMappingCreation.toString();
            String[] forMappingCreation1 = mappingCreationStatus.split("\\n");
            String MapName = null;
            for (int i = 0; i < forMappingCreation1.length; i++) {
                String Name = forMappingCreation1[i].split("\\#")[0];
                String timeStamp = forMappingCreation1[i].split("\\#")[1];
                if (Name.equalsIgnoreCase("Versioning SucessFully Done For MapName")) {
                    logDetails.append("[" + timeStamp + "]::Info::DIS::API_Mapping_creation_Call=" + '"' + "Map Name ::" + MapName + " " + '"' + "::API_Response=" + '"' + Name + '"' + "\n");
                }
                if (!Name.equalsIgnoreCase("Metadata Synup SucessFully Done") && !Name.equalsIgnoreCase("Key Values are added successfully") && !Name.equalsIgnoreCase("Invalid File Format.") && !Name.equalsIgnoreCase("Metadata Synup Failed")) {
                    MapName = Name;
                    creatingLogDetailsForCat.append("\n");
                    creatingLogDetailsForCat.append("Map " + MapName + " Created SucessFully");
                    creatingLogDetailsForCat.append("\n");
                    creatingLogDetailsForCat.append("\n");
                    logDetails.append("[" + timeStamp + "]::Info::DIS::API_Mapping_creation_Call=" + '"' + "Map Name ::" + MapName + " " + '"' + "::API_Response=" + '"' + "Mapping Created SucessFully" + '"' + "\n");

                    totalMappingCount++;
                }
                if (Name.equalsIgnoreCase("Metadata Synup SucessFully Done")) {
                    logDetails.append("[" + timeStamp + "]::Info::DIS::API_Metadata_creation_Call=" + '"' + "Map Name ::" + MapName + " " + '"' + "::API_Response=" + '"' + Name + '"' + "\n");
                }
                if (Name.equalsIgnoreCase("Metadata Synup Failed")) {
                    logDetails.append("[" + timeStamp + "]::Info::DIS::API_Metadata_creation_Call=" + '"' + "Map Name ::" + MapName + " " + '"' + "::API_Response=" + '"' + "Metadata Synup Failed" + '"' + "\n");
                }
                if (Name.equalsIgnoreCase("Key Values are added successfully")) {

                    logDetails.append("[" + timeStamp + "]::Info::DIS::API_Key Values_creation_Call=" + '"' + "Map Name ::" + MapName + " " + '"' + "::API_Response=" + '"' + Name + '"' + "\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void creationLogForFailedMapping(StringBuilder logDetails, StringBuilder forMappingCreationFailed) {
        try {
            String[] failedMapCreation = forMappingCreationFailed.toString().split("\\n");

            for (int l = 0; l < failedMapCreation.length; l++) {
                String meg = failedMapCreation[l].split("#")[0];
                if (meg.equalsIgnoreCase("Query is Not able to parse"))  {
                    faliedMappingCOunt++;
                    String timeStamp = failedMapCreation[l].split("\\#")[1];
                    String filePath = failedMapCreation[l].split("\\#")[2];
                    String check="true";
                    File f1 = new File(filePath);
                    String ext = FilenameUtils.getExtension(filePath);
                    if(ext.contains("pkb")||ext.contains("sql")||ext.contains("pks")){
                        
                    }else{
                        check="false";
                    }
                    if(check.equalsIgnoreCase("false")){
                        creatingLogDetailsForCat.append("Mapping Creation Failed : " + f1.getName());
                    }else{
                        creatingLogDetailsForCat.append("Mapping Creation Failed : " + f1.getName());
                    }
                    //creatingLogDetailsForCat.append("Mapping Creation Failed : " + f1.getName());
                    creatingLogDetailsForCat.append("\n");
                    creatingLogDetailsForCat.append("\n");
                    if (over.equalsIgnoreCase("OverView")) {
                        continue;
                    }
                    if(ext.contains("pkb")||ext.contains("sql")||ext.contains("pks")){
                        logDetails.append(("[" + timeStamp + "]::Warning::DIS::API_Mapping_creation_Call=" + " Failed " + '"' + "Mapping Path ::" + filePath + " " + '"' + "::API_Response=" + '"' + meg + '"' + "\n"));
                    }else{
                        logDetails.append(("[" + timeStamp + "]::Warning::DIS::API_Mapping_creation_Call=" + " Failed " + '"' + "Mapping Path ::" + filePath + " " + '"' + "::API_Response=" + '"' + "Invalid File Format" + '"' + "\n"));
                    }
                   
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void creatingFotterForLog(LinkedHashMap<String, String> inputDetails, StringBuilder logDetails, int totalFileCount, int totalMappingCount, int totalNumberOfSub, int totalProjectCount, long stTime) {
        try {
            long endTime = System.currentTimeMillis();
            long startTime = stTime;

            logDetails.append("[" + inputDetails.get("TimeStamp") + "]::Footer::DIS::Execution Start Time :" + inputDetails.get("TimeStamp") + "\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Total Number of Source Files :" + totalFileCount + "\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Parsed SQL Files :" + totalMappingCount + "\n");
            //logDetails.append ("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Parsed RSD Files :" + rsdFilesCount + "\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Number of Projects Created : 1\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Number of Subjects created :" + Syncmetadata_AF_V2_Oracle.totalNumberOfSub + "\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Number of Mappings created :" + totalMappingCount + "\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Number of Mappings Not created :" + faliedMappingCOunt + "\n");
            //logDetails.append ("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Number of Errors :" + errorCount + "\n");
            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Execution End Time :" + getLogDetailsTimestamp() + "\n");

            logDetails.append("[" + getLogDetailsTimestamp() + "]::Footer::DIS::Total Execution Time :" + MillisToDayHrMinSec(endTime - stTime) + "\n");
            creatingLogDetailsForCat.append("End Time = " + getLogDetailsTimestamp());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String MillisToDayHrMinSec(long milliseconds) {
        long dy = TimeUnit.MILLISECONDS.toDays(milliseconds);

        long hr = TimeUnit.MILLISECONDS.toHours(milliseconds) - TimeUnit.DAYS.toHours(TimeUnit.MILLISECONDS.toDays(milliseconds));

        long min = TimeUnit.MILLISECONDS.toMinutes(milliseconds) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(milliseconds));

        long sec = TimeUnit.MILLISECONDS.toSeconds(milliseconds) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(milliseconds));

        long ms = TimeUnit.MILLISECONDS.toMillis(milliseconds) - TimeUnit.SECONDS.toMillis(TimeUnit.MILLISECONDS.toSeconds(milliseconds));
        return String.format("%d Days %d Hours %d Minutes %d Seconds %d Milliseconds", new Object[]{Long.valueOf(dy), Long.valueOf(hr), Long.valueOf(min), Long.valueOf(sec), Long.valueOf(ms)});
    }

    public static void clearAllStaticVar() {
        totalMappingCount = 0;
        totalProjectCount = 0;
        totalNumberOfSub = 0;
        faliedMappingCOunt = 0;
        creatingLogDetailsForCat.setLength(0);
        logDetails.setLength(0);
    }

    public static String designOverviewLogFile(StringBuilder forMappingCreation, StringBuilder forMappingCreationFailed,
            StringBuilder forSubjectCreation,
            StringBuilder forProjcetCreation, LinkedHashMap<String, String> inputDetails, int totalFileCount, String logFileName, long stTime, String overView,StringBuilder wrongFormat) {
        over = overView;
        creatingLogDetailsForCat.append("Start Time=" + inputDetails.get("TimeStamp"));

        creatingLogDetailsForCat.append("\n");

        String logFilePath = inputDetails.get("Log File Path");
        logFilePath = modifyFilePath(logFilePath);
        createHeaderDesign(logDetails, inputDetails, forProjcetCreation);
        creationLogForSubjects(logDetails, forSubjectCreation);
        
        creationLogForMappingCreation(logDetails, forMappingCreation, inputDetails);
        if (forMappingCreationFailed.length() != 0) {
            creationLogForFailedMapping(logDetails, forMappingCreationFailed);
        }
        creatingFotterForLog(inputDetails, logDetails, totalFileCount, totalMappingCount, totalNumberOfSub, totalProjectCount, stTime);

        File logFile = new File(logFilePath + "/" + logFileName + "_" + getLogTimestamp() + ".txt");
        try {

            FileUtils.writeStringToFile(logFile, logDetails.toString());

//            FileWriter myWriter = new FileWriter(logFile);
//            myWriter.write(logDetails.toString());
//            myWriter.write(log);
            creatingLogDetailsForCat.append("\n");
            return creatingLogDetailsForCat.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void createHeaderDesign(StringBuilder logDetails, LinkedHashMap<String, String> inputDetails, StringBuilder forProjcetCreation) {

        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Execution Info::").append(inputDetails.get("Connector Name")).append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Execution Info:: DIS Version::").append(inputDetails.get("Dis Version")).append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Execution Info::").append(ServerInfo.getServerInfo()).append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Project Name=").append('"').append(inputDetails.get("Project Name")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Database dbvendslor=").append('"').append(inputDetails.get("Database dbvendor")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Version Control=").append('"').append(inputDetails.get("Version Control")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Input File Option=").append('"').append(inputDetails.get("Input File Option")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Upload SQL Files=").append('"').append(inputDetails.get("Upload SQL Files")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Source File Management=").append('"').append(inputDetails.get("Source File Management")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Archive Source File Path=").append('"').append(inputDetails.get("Archive Source File Path")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Log File Generation=").append('"').append(inputDetails.get("LogDecide")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Log File Path=").append('"').append(inputDetails.get("Log File Path")).append('"').append("\n");
        if (inputDetails.get("Log File Path").contains("/")) {
            String metaPath = inputDetails.get("Metadata JSON Path");
            metaPath = metaPath.replaceAll("\\\\", "/");
            logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Metadata JSON Path=").append('"').append(metaPath).append('"').append("\n");
        } else {
            logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Metadata JSON Path=").append('"').append(inputDetails.get("Metadata JSON Path")).append('"').append("\n");
        }

        //logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::Metadata JSON Path=").append('"').append(inputDetails.get("Metadata JSON Path")).append('"').append("\n");
        logDetails.append("[").append(inputDetails.get("TimeStamp")).append("]::Header::Input Parameter::SQL File Path=").append('"').append(inputDetails.get("SQL File Path")).append('"').append("\n");

        if (forProjcetCreation.toString().contains("Project Alreday Exist Having Name")) {
            logDetails.append("[").append(getLogDetailsTimestamp()).append("]::Info::DIS::API_Project_creation_Call=").append('"').append(inputDetails.get("Project Name")).append('"').append("::API_Response=").append('"').append("Project Already Exist").append('"').append("\n");
        } else {
            totalProjectCount++;
            creatingLogDetailsForCat.append("Project_Name : " + inputDetails.get("Project Name"));
            creatingLogDetailsForCat.append("\n");

            logDetails.append("[").append(getLogDetailsTimestamp()).append("]::Info::DIS::API_Project_creation_Call=").append('"').append(inputDetails.get("Project Name")).append('"').append("::API_Response=").append('"').append("Project Created").append('"').append("\n");
        }
    }

    private static void creationLogForWrongFormat(StringBuilder logDetails, StringBuilder forWrongFormat1) {
        try{
            String msg=forWrongFormat1.toString();
            
            String[] meg1=msg.split("#");
            
            for(int k=0;k<meg1.length;k++){
                String meg=meg1[k].split("#")[0];
                String timeStamp=meg1[k].split("#")[1];
                logDetails.append("[" + timeStamp + "]::Info::DIS::API_Mapping_creation_Call=" + '"' + "Map Name ::" + meg + " " + '"' + "::API_Response=" + '"' + "Wrong FIle Format" + '"' + "\n");
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
