/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.erwin.cfx.connectors.metadataZA;

import java.util.ArrayList;

/**
 *
 * @author PrajnaSurya
 */
public class Syncmetadata_AF_V2_NewMetaSynup {
    
   
}
