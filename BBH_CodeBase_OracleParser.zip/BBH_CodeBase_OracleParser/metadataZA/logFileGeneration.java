
import java.util.LinkedHashMap;











public class logFileGeneration{
    
    public static String generateLogFile(LinkedHashMap<String,String> inputDetails){
        
        return null;
        
    }
    
    
}